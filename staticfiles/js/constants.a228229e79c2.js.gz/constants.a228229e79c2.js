export const scaleFactor = 2.3;

export const dialogueData = {
    // House1: [
    //   { type: "line", speaker: "House1", content: "House1." }
    // ],
    // House2: [
    //   { type: "line", speaker: "House2", content: "House2." }
    // ],
    // House3: [
    //   { type: "line", speaker: "House3", content: "House3." }
    // ],
    // House4: [
    //   { type: "line", speaker: "House4", content: "House4." }
    // ],
    // House5: [
    //   { type: "line", speaker: "House5", content: "House5." }
    // ],
    // City_House1: [
    //   { type: "line", speaker: "City_House1", content: "City_House1." }
    // ],
    // City_House2: [
    //   { type: "line", speaker: "City_House2", content: "City_House2." }
    // ],
    // Desert: [
    //   { type: "line", speaker: "Desert", content: "Desert." }
    // ],
  
    bulletin1: [
        {
            type: "line",
            speaker: "bulletin1",
            content: "<a href=\"/static/pdf/基礎概念\" target=\"_blank\" style=\"text-decoration: none\">基礎概念</a>",
        }
    ],
  
    // bulletin2: [
    //   {
    //     type: "line",
    //     speaker: "bulletin2",
    //     content: `第一單元「基礎概念」<a href="https://www.canva.com/design/DAGhECrGS9M/eDmQoSKl4sHcWr1by3RzdA/edit?utm_content=DAGhECrGS9M&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank" style="text-decoration: none">連結</a>`,
    //   }
    // ],
    // bulletin3: [
    //   {
    //     type: "line",
    //     speaker: "bulletin3",
    //     content: `第二單元「相等性」<a href="https://www.canva.com/design/DAGhYhO-kMY/DRN3m9PE7Nqo_iTnppe9mg/edit?utm_content=DAGhYhO-kMY&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank" style="text-decoration: none">連結</a>`,
    //   }
    // ],
    // bulletin4: [
    //   {
    //     type: "line",
    //     speaker: "bulletin4",
    //     content: `第三單元「迴圈」<a href="https://www.canva.com/design/DAGiYZlgG2g/ALJ2kqqL3LbcYN8Nu13Hiw/edit?utm_content=DAGiYZlgG2g&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank" style="text-decoration: none">連結</a>`,
    //   }
    // ],
    // bulletin5: [
    //   {
    //     type: "line",
    //     speaker: "bulletin5",
    //     content: `第四單元「邏輯控制」<a href="https://www.canva.com/design/DAGiYQVFY6E/qFEA8PtjpCTKHKcgxxRldg/edit?utm_content=DAGiYQVFY6E&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank" style="text-decoration: none">連結</a>`,
    //   }
    // ],
  
    // King: [
    //   { type: "line", speaker: "King", content: "King. I like to play chess with him." }
    // ],
    // Nan: [
    //   { type: "line", speaker: "Nan", content: "Nan" }
    // ],
    // npc_1: [
    //   { type: "line", speaker: "npc_1", content: "npc_1." }
    // ],
    // npc_2: [
    //   { type: "line", speaker: "npc_2", content: "npc_2." }
    // ],
    // npc_3: [
    //   { type: "line", speaker: "npc_3", content: "npc_3." }
    // ],
    // npc_4: [
    //   { type: "line", speaker: "npc_4", content: "npc_4." }
    // ],
    // npc_5: [
    //   { type: "line", speaker: "npc_5", content: "npc_5." }
    // ],
    // crack_blue_1: [
    //   { type: "line", speaker: "crack_blue_1", content: "crack_blue_1." }
    // ],
    // crack_red_1: [
    //   { type: "line", speaker: "crack_red_1", content: "crack_red_2." }
    // ],
    // crack_blue_2: [
    //   { type: "line", speaker: "crack_blue_2", content: "crack_blue_2." }
    // ],
    // crack_red_2: [
    //   { type: "line", speaker: "crack_red_2", content: "crack_red_2." }
    // ],
    // crack_blue_3: [
    //   { type: "line", speaker: "crack_blue_3", content: "crack_blue_3." }
    // ],
    // crack_red_3: [
    //   { type: "line", speaker: "crack_red_3", content: "crack_red_3." }
    // ],
    // crack_blue_4: [
    //   { type: "line", speaker: "crack_blue_4", content: "crack_blue_4." }
    // ],
    // crack_red_4: [
    //   { type: "line", speaker: "crack_red_4", content: "crack_red_4." }
    // ],
    // big_crack: [
    //   { type: "line", speaker: "big_crack", content: "big_crack." }
    // ],
};  